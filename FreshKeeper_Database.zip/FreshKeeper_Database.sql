-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: freshkeeper
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categories`
--

DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `cate_id` int NOT NULL AUTO_INCREMENT,
  `cate_name` varchar(100) COLLATE utf8mb4_general_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categories`
--

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (0,'Proteins','Foods high in protein like meat, fish, eggs, and tofu.'),(1,'Carbohydrates','Foods rich in carbohydrates like rice, pasta, bread, and potatoes.'),(2,'Fats','Foods containing healthy fats like avocados, nuts, seeds, and olive oil.'),(3,'Dairy','Dairy products such as milk, cheese, yogurt, and butter.'),(4,'Vegetables','Various vegetables like broccoli, spinach, carrots, and peppers.'),(5,'Fruits','Fresh fruits including apples, bananas, oranges, and berries.'),(6,'Grains','Whole grains such as oats, quinoa, barley, and brown rice.'),(7,'Sugars','Foods containing sugars like sweets, candies, and desserts.'),(8,'Beverages','Drinks including water, juice, tea, coffee, and soft drinks.'),(9,'Seafood','Seafood like fish, shrimp, crab, and clams.'),(10,'Snacks','Snack foods such as chips, cookies, and crackers.'),(11,'Legumes','Foods like lentils, beans, chickpeas, and peas.'),(12,'Nuts and Seeds','Various nuts (e.g., almonds, walnuts) and seeds (e.g., chia, flax).'),(13,'Sweets and Desserts','Sweets such as chocolate, cakes, and ice cream.'),(14,'Baked Goods','Bread, muffins, cakes, and other baked products.'),(15,'Condiments and Sauces','Items like ketchup, mustard, mayonnaise, and salad dressings.'),(16,'Processed Foods','Packaged foods such as canned soup, frozen meals, and deli meats.'),(17,'Herbal and Spices','Various herbs and spices like oregano, basil, and turmeric.'),(18,'Oils','Different types of oils like olive oil, coconut oil, and sunflower oil.'),(19,'Alcoholic Beverages','Alcoholic drinks such as beer, wine, and spirits.'),(20,'Non-Alcoholic Beverages','Drinks such as soda, juice, tea, coffee, and flavored water.');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consumption`
--

DROP TABLE IF EXISTS `consumption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `consumption` (
  `con_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `item_name` varchar(255) NOT NULL,
  `con_quantity` int NOT NULL DEFAULT '0',
  `amount_spent` decimal(10,2) NOT NULL,
  `health_star_rating` enum('5','4','3','2','1') NOT NULL DEFAULT '1',
  `week_start_date` date NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`con_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `consumption_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consumption`
--

LOCK TABLES `consumption` WRITE;
/*!40000 ALTER TABLE `consumption` DISABLE KEYS */;
INSERT INTO `consumption` VALUES (1,1,'CupCake',2,12.00,'1','2024-10-20','2024-10-24 14:27:54','2024-10-24 15:18:59'),(2,1,'Blueberry',1,5.00,'5','2024-10-20','2024-10-24 14:46:15','2024-10-24 15:18:59'),(5,1,'Egg',20,15.00,'5','2024-10-20','2024-10-25 07:19:20','2024-10-25 12:21:48'),(6,1,'Grape',9,31.50,'5','2024-10-20','2024-10-25 07:44:17','2024-10-25 12:21:48'),(7,1,'Banana',6,10.00,'5','2024-10-20','2024-10-25 07:48:20','2024-10-25 12:21:48'),(8,1,'Beef',2,50.00,'5','2024-10-20','2024-10-25 07:53:38','2024-10-25 07:56:57'),(9,2,'Apple',3,7.50,'5','2024-10-20','2024-10-25 08:01:06','2024-10-25 08:02:41'),(10,1,'IceCream',1,25.00,'2','2024-10-20','2024-10-25 12:20:35','2024-10-25 12:21:48'),(11,1,'Avocado',1,2.50,'5','2024-10-20','2024-10-25 12:46:03','2024-10-25 12:46:44'),(12,1,'Pear',1,3.00,'5','2024-10-20','2024-10-25 12:50:44','2024-10-25 12:50:44');
/*!40000 ALTER TABLE `consumption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `expiration_date` date DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `unit_price` float NOT NULL,
  `quantity` int DEFAULT '1',
  `health_star_rating` enum('5','4','3','2','1') COLLATE utf8mb4_general_ci NOT NULL DEFAULT '1',
  `preference` enum('yes','no') COLLATE utf8mb4_general_ci NOT NULL DEFAULT 'no',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `items_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`),
  CONSTRAINT `items_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `categories` (`cate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `items`
--

LOCK TABLES `items` WRITE;
/*!40000 ALTER TABLE `items` DISABLE KEYS */;
INSERT INTO `items` VALUES (6,1,'Grape','2024-10-25',5,3.5,3,'5','no','2024-10-22 11:04:06','2024-10-25 08:08:02'),(7,2,'Oliver Oil','2026-12-28',18,25,1,'4','yes','2024-10-23 06:04:54','2024-10-24 13:31:03'),(20,1,'Milk','2024-10-25',3,6.95,1,'5','yes','2024-10-25 07:35:02','2024-10-25 08:08:02'),(21,1,'Egg','2024-10-26',0,1,10,'5','yes','2024-10-25 07:35:39','2024-10-25 07:41:16'),(24,2,'Beef','2024-10-31',0,50,2,'5','yes','2024-10-25 07:59:49','2024-10-25 08:08:02'),(30,1,'Apple','2024-10-25',5,3,1,'5','yes','2024-10-25 12:53:19','2024-10-25 12:53:19'),(31,1,'Strawberry','2024-10-29',5,6,1,'5','yes','2024-10-26 19:20:10','2024-10-26 19:20:10');
/*!40000 ALTER TABLE `items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `preferences`
--

DROP TABLE IF EXISTS `preferences`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `preferences` (
  `preference_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int DEFAULT NULL,
  `item_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `prefer_quantity` int DEFAULT '1',
  `frequency` enum('Daily','Weekly','Monthly','Occasionally') COLLATE utf8mb4_general_ci DEFAULT 'Weekly',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`preference_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `preferences_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `preferences`
--

LOCK TABLES `preferences` WRITE;
/*!40000 ALTER TABLE `preferences` DISABLE KEYS */;
INSERT INTO `preferences` VALUES (1,1,'Milk',1,'Weekly','2024-10-22 02:37:25','2024-10-22 02:37:25'),(2,1,'Egg',1,'Weekly','2024-10-22 04:56:55','2024-10-22 04:56:55'),(3,2,'Oliver Oil',1,'Weekly','2024-10-23 06:04:54','2024-10-23 06:04:54'),(5,1,'Bread',1,'Monthly','2024-10-23 13:08:53','2024-10-23 13:08:53'),(6,1,'Blue berry',1,'Weekly','2024-10-24 07:03:58','2024-10-24 07:03:58'),(7,1,'Apple',1,'Weekly','2024-10-24 07:58:57','2024-10-24 07:58:57'),(10,1,'Beef',1,'Weekly','2024-10-24 10:34:00','2024-10-24 10:34:00'),(11,1,'Pear',1,'Weekly','2024-10-24 11:00:54','2024-10-24 11:00:54'),(12,1,'Strawberry',1,'Weekly','2024-10-24 15:51:23','2024-10-24 15:51:23'),(13,1,'Avocado',1,'Weekly','2024-10-24 16:04:42','2024-10-24 16:04:42'),(14,2,'Beef',1,'Weekly','2024-10-25 07:59:49','2024-10-25 07:59:49'),(15,2,'Apple',1,'Weekly','2024-10-25 08:00:11','2024-10-25 08:00:11');
/*!40000 ALTER TABLE `preferences` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `password` varchar(15) COLLATE utf8mb4_general_ci NOT NULL,
  `height` decimal(5,2) NOT NULL,
  `weight` decimal(5,2) NOT NULL,
  `age` int NOT NULL,
  `body_index` decimal(5,2) DEFAULT NULL,
  `health_requirement` enum('Weight Loss','Weight Gain','Muscle Gain','Maintenance') COLLATE utf8mb4_general_ci DEFAULT 'Maintenance',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Chloe','123456',158.00,50.00,30,20.03,'Weight Loss','2024-10-21 11:02:37','2024-10-24 12:54:10'),(2,'Peter','234567',175.00,75.00,31,24.49,'Weight Loss','2024-10-22 00:32:44','2024-10-24 12:54:10'),(3,'Lihao','123456',180.00,80.00,28,18.52,'Maintenance','2024-10-22 04:56:11','2024-10-24 12:54:10'),(4,'Laura','345678',165.00,49.00,23,19.10,'Maintenance','2024-10-23 12:31:58','2024-10-24 12:54:10'),(5,'Scott','456789',175.00,72.00,31,24.49,'Weight Loss','2024-10-23 12:34:08','2024-10-24 12:54:10'),(6,'Hailey','123456',167.00,52.00,24,19.72,'Maintenance','2024-10-23 12:41:35','2024-10-24 12:54:10'),(7,'David','123456',178.00,80.00,32,25.25,'Maintenance','2024-10-24 12:57:45','2024-10-24 12:57:45');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-27 12:46:16
